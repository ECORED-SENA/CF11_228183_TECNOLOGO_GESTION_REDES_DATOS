function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6ZopXom1KHG":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

